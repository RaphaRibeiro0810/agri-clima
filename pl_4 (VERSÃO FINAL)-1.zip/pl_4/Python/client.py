import socket
HOST = 'localhost'
PORT = 12345

def makeRequest(parameter, value):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
        client_socket.connect(('localhost', 12345))

        # Send a message to the Java server
        message = f"{parameter},{value}"
        client_socket.sendall(message.encode())

        # Shutdown the client socket
        client_socket.shutdown(socket.SHUT_WR)  
        print(f"Sent to Java server: {message}")

        # Receive a response from the Java server
        response = client_socket.recv(1024).decode()
        response = response
        
        # Remove the \n from the end of the response
        response = response.replace("\n", "")

        if response == '':
            response = "Received from Java server: No response"

        return response

# makeRequest('temperatura_orvalho_maxima', '1.2')
