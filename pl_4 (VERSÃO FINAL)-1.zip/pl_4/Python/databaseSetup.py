import mysql.connector
import os

class database:
    def __init__(self):
        self.db = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            database="projetointegradorquatro"
        )
        self.cursor = self.db.cursor()
        self.createTables()
    
    def insert(self, string):
        try:
            self.cursor.execute(string)
            self.db.commit()
            return True
        except Exception as e:
            print("Error while inserting: ", e)
            print("SQL: ", string)
            return False

    def select(self, string):
        try:
            self.cursor.execute(string)
            return self.cursor.fetchall()
        except Exception as e:
            print("Error while selecting: ", e)
            print("SQL: ", string)
            return []

    def createTables(self):
        sqlTable1 = "CREATE TABLE `DadosMeteorologicos` ( `id` int NOT NULL AUTO_INCREMENT, `estacao_id` varchar(10) DEFAULT NULL, `data` date DEFAULT NULL, `hora` time DEFAULT NULL, `precipitacao_total` decimal(8,2) DEFAULT NULL, `pressao_atmosferica` decimal(8,2) DEFAULT NULL, `pressao_atmosferica_maxima` decimal(8,2) DEFAULT NULL, `pressao_atmosferica_minima` decimal(8,2) DEFAULT NULL, `radiacao_global` decimal(8,2) DEFAULT NULL, `temperatura` decimal(5,2) DEFAULT NULL, `temperatura_orvalho` decimal(5,2) DEFAULT NULL, `temperatura_maxima` decimal(5,2) DEFAULT NULL, `temperatura_minima` decimal(5,2) DEFAULT NULL, `temperatura_orvalho_maxima` decimal(5,2) DEFAULT NULL, `temperatura_orvalho_minima` decimal(5,2) DEFAULT NULL, `umidade_maxima` decimal(5,2) DEFAULT NULL, `umidade_minima` decimal(5,2) DEFAULT NULL, `umidade_relativa` decimal(5,2) DEFAULT NULL, `vento_direcao` decimal(8,2) DEFAULT NULL, `vento_rajada_maxima` decimal(5,2) DEFAULT NULL, `vento_velocidade` decimal(5,2) DEFAULT NULL, PRIMARY KEY (`id`), KEY `estacao_id` (`estacao_id`) )"
        sqlTable2 = "CREATE TABLE `EstacoesMeteorologicas` ( `id` int NOT NULL AUTO_INCREMENT, `regiao` varchar(255) DEFAULT NULL, `uf` varchar(255) DEFAULT NULL, `estacao` varchar(255) DEFAULT NULL, `codigo` varchar(10) NOT NULL, `latitude` decimal(10,8) DEFAULT NULL, `longitude` decimal(11,8) DEFAULT NULL, `altitude` decimal(8,2) DEFAULT NULL, `data_fundacao` date DEFAULT NULL, PRIMARY KEY (`id`), UNIQUE KEY `codigo_UNIQUE` (`codigo`) )"
        
        # Check if DadosMeteorologicos exists
        sql = "SELECT 1 FROM information_schema.tables WHERE table_name = 'DadosMeteorologicos' LIMIT 1;"
        result = self.select(sql)
        if len(result) == 0:
            self.cursor.execute(sqlTable1)
        else:
            print('Tabela DadosMeteorologicos existe')

        # Check if EstacoesMeteorologicas exists
        sql = "SELECT 1 FROM information_schema.tables WHERE table_name = 'EstacoesMeteorologicas' LIMIT 1;"
        result = self.select(sql)
        if len(result) == 0:
            self.cursor.execute(sqlTable2)
        else:
            print('Tabela EstacoesMeteorologicas existe')