from flask import Flask, request, jsonify
from databaseSetup import database
from generateInserts import generateInserts
from datetime import datetime
from client import makeRequest
import time

import sys
sys.setrecursionlimit(100000000)  # Set a higher value

app = Flask(__name__)
db = database()
gen = generateInserts(db)

# You can either run the gen.run() function below, or call the route /run
# gen.run()

# Create root (endpoint example for later)
@app.route('/')
def home():
    return "Home, route working fine"

# SERVER ROUTE, ASK FOR PARAMETER AND VALUE
@app.route('/serverRequest/<parameter>/<value>', methods=['GET'])
def serverRequest(parameter, value):
    try:
        serverResponse = makeRequest(parameter, value)
        response = jsonify({'message': 'serverRequest', 'parameter': parameter, 'value': value, 'response': serverResponse})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 200
    except Exception as e:
        print("Error while serverRequest: ", e)
        response = jsonify({'message': 'Error while serverRequest', 'error': str(e)})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 500

# WORKING FINE 26-NOVEMBER
@app.route('/update-2023', methods=['GET'])
def update_2023():
    try:
        gen.update2023()
        response = jsonify({'message': 'update-2023'})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 200
    except Exception as e:
        print("Error while updating 2023: ", e)
        response = jsonify({'message': 'Error while updating 2023', 'error': str(e)})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 500

# WORKING FINE 26-NOVEMBER
@app.route('/run', methods=['GET'])
def run():
    try:
        gen.run()
        response = jsonify({'message': 'run'})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 200
    except Exception as e:
        print("Error while running: ", e)
        response = jsonify({'message': 'Error while running', 'error': str(e)})
        response.headers.add('Access-Control-Allow-Origin', '*')
        return response, 500

@app.route('/getStations', methods=['GET'])
def getStations():
    sql = "SELECT codigo, estacao FROM EstacoesMeteorologicas"
    res = db.select(sql)
    response = jsonify({'message': 'getStations', 'stations': res, 'sql': sql})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

@app.route('/getMonthLabel/<date_start>/<date_end>', methods=['GET'])
def getMonthLabel(date_start, date_end):
    sql = "SELECT DISTINCT DATE_FORMAT(data, '%Y-%m') AS month_year FROM DadosMeteorologicos WHERE data BETWEEN '" + date_start + "' AND '" + date_end + "'"
    res = db.select(sql)
    response = jsonify({'message': 'getMonthLabel', 'dateStart': date_start, 'dateEnd': date_end, 'months': res, 'sql': sql})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

@app.route('/getDayLabel/<date_start>/<date_end>', methods=['GET'])
def getDayLabel(date_start, date_end):
    sql = "SELECT DISTINCT DATE_FORMAT(data, '%Y-%m-%d') AS day_month_year FROM DadosMeteorologicos WHERE data BETWEEN '" + date_start + "' AND '" + date_end + "'"
    res = db.select(sql)
    response = jsonify({'message': 'getDayLabel', 'dateStart': date_start, 'dateEnd': date_end, 'days': res, 'sql': sql})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

@app.route('/getHourLabel/<date_start>/<date_end>', methods=['GET'])
def getHourLabel(date_start, date_end):
    sql = "SELECT DISTINCT CONCAT( DATE_FORMAT(data, '%d/%m/%Y'), ' ', hora ) AS formatted_datetime FROM DadosMeteorologicos WHERE data BETWEEN '" + date_start + "' AND '" + date_end + "'"
    res = db.select(sql)
    response = jsonify({'message': 'getHourLabel', 'dateStart': date_start, 'dateEnd': date_end, 'hours': res, 'sql': sql})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

@app.route('/getMonthData/<date_start>/<date_end>/<station>', methods=['GET'])
def getMonthData(date_start, date_end, station):
    if station == 'all':
        sql = "SELECT DATE_FORMAT(data, '%m/%Y') AS month_year, AVG(vento_velocidade) AS radiacao FROM DadosMeteorologicos WHERE data BETWEEN '" + date_start + "' AND '" + date_end + "' GROUP BY month_year"
    else:
        sql = "SELECT DATE_FORMAT(data, '%m/%Y') AS month_year, AVG(vento_velocidade) AS radiacao FROM DadosMeteorologicos WHERE data BETWEEN '" + date_start + "' AND '" + date_end + "' AND estacao_id = '" + station + "' GROUP BY month_year"
    res = db.select(sql)
    res = sorted(res, key=lambda x: time.strptime(x[0], '%m/%Y'))
    response = jsonify({'message': 'getMonthData', 'dateStart': date_start, 'dateEnd': date_end, 'res': res, 'sql': sql})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

@app.route('/getRadiationWeek/<date_start>/<date_end>/<station>', methods=['GET'])
def getRadiationWeek(date_start, date_end, station):
    if station == 'all':
        sql = "SELECT DATE_FORMAT(data, '%Y/%u') AS week_year, AVG(radiacao_global) AS radiacao FROM DadosMeteorologicos WHERE data BETWEEN '" + date_start + "' AND '" + date_end + "' GROUP BY week_year ORDER BY week_year;"
    else:
        sql = "SELECT DATE_FORMAT(data, '%Y/%u') AS week_year, AVG(radiacao_global) AS radiacao FROM DadosMeteorologicos WHERE data BETWEEN '" + date_start + "' AND '" + date_end + "' AND estacao_id = '" + station + "' GROUP BY week_year ORDER BY week_year;"
    res = db.select(sql)
    response = jsonify({'message': 'getRadiationWeek', 'dateStart': date_start, 'dateEnd': date_end, 'radiation': res, 'sql': sql})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

@app.route('/getDailyUpdate/<date_start>/<date_end>/<station>', methods=['GET'])
def getDailyUpdate(date_start, date_end, station):
    if station == 'all':
        sql = """
            SELECT day_month_year, umidade_relativa
            FROM (
                SELECT DATE_FORMAT(data, '%d/%m/%Y') AS day_month_year, AVG(umidade_relativa) AS umidade_relativa
                FROM DadosMeteorologicos
                WHERE data BETWEEN '{}' AND '{}'
                GROUP BY day_month_year
            ) AS subquery
            ORDER BY STR_TO_DATE(day_month_year, '%d/%m/%Y');
        """.format(date_start, date_end)
    else:
        sql = """
            SELECT day_month_year, umidade_relativa
            FROM (
                SELECT DATE_FORMAT(data, '%d/%m/%Y') AS day_month_year, AVG(umidade_relativa) AS umidade_relativa
                FROM DadosMeteorologicos
                WHERE data BETWEEN '{}' AND '{}'
                AND estacao_id = '{}'
                GROUP BY day_month_year
            ) AS subquery
            ORDER BY STR_TO_DATE(day_month_year, '%d/%m/%Y');
        """.format(date_start, date_end, station)
    res = db.select(sql)
    response = jsonify({'message': 'getDailyUpdate', 'dateStart': date_start, 'dateEnd': date_end, 'res': res, 'sql': sql})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

@app.route('/getClimogramaDataset/<date_start>/<date_end>/<station>', methods=['GET'])
def getClimogramaDataset(date_start, date_end, station):
    if station == 'all':
        sql = """
            SELECT DATE_FORMAT(data, '%m/%Y') AS month_year, 
            AVG(precipitacao_total) AS precipitacao_total, 
            AVG(temperatura) AS temperatura 
            FROM DadosMeteorologicos 
            WHERE data BETWEEN '{}' AND '{}' GROUP BY month_year
        """.format(date_start, date_end)
    else:
        sql = """
            SELECT DATE_FORMAT(data, '%m/%Y') AS month_year, 
            AVG(precipitacao_total) AS precipitacao_total, 
            AVG(temperatura) AS temperatura 
            FROM DadosMeteorologicos 
            WHERE data BETWEEN '{}' AND '{}' AND estacao_id = '{}' GROUP BY month_year
        """.format(date_start, date_end, station)
    res = db.select(sql)
    res = sorted(res, key=lambda x: time.strptime(x[0], '%m/%Y'))
    datasetLine = []
    datasetBar = []
    labels = []
    for row in res:
        labels.append(row[0])
        datasetLine.append(row[1])
        datasetBar.append(row[2])
    dataset = {
        'labels': labels,
        'datasets': [
            {
                'type': 'line',
                'label': 'Precipitacao Total',
                'borderColor': 'rgb(255, 99, 132)',
                'borderWidth': 2,
                'fill': False,
                'data': datasetLine
            },
            {
                'type': 'bar',
                'label': 'Temperatura',
                'backgroundColor': 'rgb(75, 192, 192)',
                'data': datasetBar,
                'borderColor': 'white',
                'borderWidth': 2,
            }
        ]
    }
    # PRint a pretty dataset formatted on terminal
    response = jsonify({'message': 'getFixedDataset', 'dateStart': date_start, 'dateEnd': date_end, 'dataset': dataset, 'sql': sql, 'labels': labels})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

# Get hourly update of temperature STOPPED HERE TEST MORE
@app.route('/getFixedDataset', methods=['GET'])
def getFixedDataset():
    dateStart = "2019-01-01"
    dateEnd = "2023-12-31"
    sql = """
        SELECT DATE_FORMAT(data, '%m') AS month_year, 
        AVG(precipitacao_total) AS precipitacao_total, 
        AVG(temperatura) AS temperatura 
        FROM DadosMeteorologicos 
        WHERE data BETWEEN '2019-01-01' AND '2023-12-31' GROUP BY month_year
    """
    res = db.select(sql)
    res = sorted(res, key=lambda x: time.strptime(x[0], '%m'))
    months = [ 'Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Nov', 'Dez' ]
    datasetLine = []
    datasetBar = []
    labels = []
    for row in res:
        labels.append(row[0])
        datasetLine.append(row[1])
        datasetBar.append(row[2])
    dataset = {
        'labels': [ 'Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Nov', 'Dez' ],
        'datasets': [
            {
                'type': 'line',
                'label': 'Precipitacao Total',
                'borderColor': 'rgb(255, 99, 132)',
                'borderWidth': 2,
                'fill': False,
                'data': datasetLine
            },
            {
                'type': 'bar',
                'label': 'Temperatura',
                'backgroundColor': 'rgb(75, 192, 192)',
                'data': datasetBar,
                'borderColor': 'white',
                'borderWidth': 2,
            }
        ]
    }
    # PRint a pretty dataset formatted on terminal
    response = jsonify({'message': 'getFixedDataset', 'dateStart': dateStart, 'dateEnd': dateEnd, 'dataset': dataset, 'sql': sql, 'labels': labels})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

@app.route('/getMixData/<date_start>/<date_end>/<station>', methods=['GET'])
def getAvg(date_start, date_end, station):
    cols = ['temperatura', 'precipitacao_total', 'temperatura_maxima', 'temperatura_minima']
    
    avgStrings = []
    maxStrings = []
    minStrings = []
    for col in cols:
        avgStrings.append(f'AVG({col}) AS {col}avg')
        maxStrings.append(f'MAX({col}) AS {col}max')
        minStrings.append(f'MIN({col}) AS {col}min')
    avgString = ', '.join(avgStrings)
    maxString = ', '.join(maxStrings)
    minString = ', '.join(minStrings)

    if station == 'all':
        sql = f"SELECT {', '.join([avgString, maxString, minString])} FROM DadosMeteorologicos WHERE data BETWEEN '{date_start}' AND '{date_end}'"
    else:
        sql = f"SELECT {', '.join([avgString, maxString, minString])} FROM DadosMeteorologicos WHERE data BETWEEN '{date_start}' AND '{date_end}' AND estacao_id = '{station}'"
    res = db.select(sql)

    result_dict = {
        'dateStart': date_start,
        'dateEnd': date_end,
        'mixData': []
    }

    for row in res:
        data_dict = {}
        for i, col in enumerate(cols):
            data_dict[f"{col}_avg"] = row[i]
            data_dict[f"{col}_max"] = row[i + len(cols)]
            data_dict[f"{col}_min"] = row[i + 2 * len(cols)]
        result_dict['mixData'].append(data_dict)

    response = jsonify({'message': 'getAvg', **result_dict, 'sql': sql})
    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

# Run API 
if __name__ == '__main__':
    app.run(debug=True)
