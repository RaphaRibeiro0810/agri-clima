import datetime

def format_time_for_database(input_str):
    try:
        time_parts = input_str.split(' ')[0]
        hour = int(time_parts[:2])
        minute = int(time_parts[2:4])
        time_obj = datetime.time(hour, minute)
        time_str = time_obj.strftime("%H:%M:%S")
        return time_str
    except ValueError:
        print("Error while formatting time: ", input_str)
        return None
