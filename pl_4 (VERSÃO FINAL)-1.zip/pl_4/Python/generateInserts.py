import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
import os
import requests
import numpy as np
import pandas as pd
from auxFunctions import format_time_for_database
from databaseSetup import database
from zipfile import ZipFile

class generateInserts:
    def __init__(self, db):
        # Years, except 2023 :)
        self.YEARS = ["2022", "2021", "2020", "2019"]
        # DIR with data
        self.DIR = os.path.dirname(os.path.abspath(__file__)) + '/../Dados'
        # Database    
        self.db = db

    # Get CSV Data
    def get_header_from_csv(self, filename, FOLDER_YEAR):
        if filename.endswith(".CSV"):
            file_path = os.path.join(FOLDER_YEAR, filename)
            df = pd.read_csv(file_path, nrows=7, encoding="ISO-8859-1", sep=";", decimal=",", header=None)
            df.fillna("NULL", inplace=True)
            try: 
                data = {
                    "regiao": df[1][0],
                    "uf": df[1][1],
                    "estacao": df[1][2],
                    "codigo": df[1][3],
                    "latitude": df[1][4].replace(",", "."),
                    "longitude": df[1][5].replace(",", "."),
                    "altitude": df[1][6].replace(",", ".")
                }
            except Exception as e:
                print("Error while parsing header: ", e)
                print("Header: ", df)
                return None
            return data

    def get_data_from_csv(self, filename, FOLDER_YEAR):
        if filename.endswith(".CSV"):
            header_rows_to_skip = 9 # set to 8 if want header
            file_path = os.path.join(FOLDER_YEAR, filename)
            dfBody = pd.read_csv(file_path, skiprows=header_rows_to_skip, encoding="ISO-8859-1", sep=";", decimal=",", header=None)
            dfBody.fillna("NULL", inplace=True)
            result = []
            for row in dfBody.iterrows():
                try:
                    data = {
                        "data": row[1][0].replace("/", "-"),
                        "hora": format_time_for_database(row[1][1]),
                        "precipitacao_total": row[1][2],
                        "pressao_atmosferica": row[1][3],
                        "pressao_atmosferica_max": row[1][4],
                        "pressao_atmosferica_min": row[1][5],
                        "radiacao_global": row[1][6],
                        "temperatura_ar": row[1][7],
                        "temperatura_ponto_orvalho": row[1][8],
                        "temperatura_max": row[1][9],
                        "temperatura_min": row[1][10],
                        "temperatura_orvalho_max": row[1][11],
                        "temperatura_orvalho_min": row[1][12],
                        "umidade_relativa_max": row[1][13],
                        "umidade_relativa_min": row[1][14],
                        "umidade_relativa": row[1][15],
                        "vento_direcao": row[1][16],
                        "vento_rajada_max": row[1][17],
                        "vento_velocidade": row[1][18],
                    }
                except Exception as e:
                    print("Error while parsing row: ", e)
                    print("Row: ", row)
                    continue
                result.append(data)
            return result

    # Insert Data
    def insert_header(self, header):
        sqlSelect = f"SELECT * FROM EstacoesMeteorologicas WHERE codigo = '{header['codigo']}'"
        result = self.db.select(sqlSelect)
        if len(result) == 0:
            sql = f"INSERT INTO EstacoesMeteorologicas (regiao, uf, estacao, codigo, latitude, longitude, altitude) VALUES ('{header['regiao']}', '{header['uf']}', '{header['estacao']}', '{header['codigo']}', '{header['latitude']}', '{header['longitude']}', '{header['altitude']}')"
            self.db.insert(sql)

    def insert_data(self, data, estacao_id):
        data = data
        sqlSelect = f"SELECT * FROM DadosMeteorologicos WHERE data = '{data['data']}' AND hora = '{data['hora']}' AND estacao_id = '{estacao_id}'"
        result = self.db.select(sqlSelect)
        if len(result) == 0:
            sqlInsert = f"INSERT INTO DadosMeteorologicos (estacao_id ,data, hora, precipitacao_total, pressao_atmosferica, pressao_atmosferica_maxima, pressao_atmosferica_minima, radiacao_global, temperatura, temperatura_orvalho, temperatura_maxima, temperatura_minima, temperatura_orvalho_maxima, temperatura_orvalho_minima, umidade_maxima, umidade_minima, umidade_relativa, vento_direcao, vento_rajada_maxima, vento_velocidade) VALUES ('{estacao_id}','{data['data']}', '{data['hora']}', {data['precipitacao_total']}, {data['pressao_atmosferica']}, {data['pressao_atmosferica_max']}, {data['pressao_atmosferica_min']}, {data['radiacao_global']}, {data['temperatura_ar']}, {data['temperatura_ponto_orvalho']}, {data['temperatura_max']}, {data['temperatura_min']}, {data['temperatura_orvalho_max']}, {data['temperatura_orvalho_min']}, {data['umidade_relativa_max']}, {data['umidade_relativa_min']}, {data['umidade_relativa']}, {data['vento_direcao']}, {data['vento_rajada_max']}, {data['vento_velocidade']})"
            self.db.insert(sqlInsert)
            print("Insert: ", estacao_id, data['data'], data['hora'])
        else:
            print("Data already exists: ", estacao_id, data['data'], data['hora'])
        return False

    # Download Year
    def download2023(self):
        try:
            # For future, download zip file, delete current 2023 folder contents, unzip downloaded file to 2023 folder
            # Then run this function to update database with new data from 2023 in 2023 folder
            print('Downloading 2023')
            URL = "https://portal.inmet.gov.br/uploads/dadoshistoricos/2023.zip" 
            dir2023 = os.path.join(self.DIR, "2023")
            if not os.path.exists(dir2023):
                os.mkdir(dir2023)
            else:
                for filename in os.listdir(dir2023):
                    os.remove(os.path.join(dir2023, filename))
            # Download zip file to Dados folder
            r = requests.get(URL, allow_redirects=True)
            open(os.path.join(dir2023, '2023.zip'), 'wb').write(r.content)
            # Unzip file
            os.system(f"unzip {os.path.join(dir2023, '2023.zip')} -d {dir2023}")
            # Now we delete everything except the CSV files that have "A110", "A837" and "A348" in their name
            for filename in os.listdir(dir2023):
                if not filename.endswith(".CSV"):
                    os.remove(os.path.join(dir2023, filename))
                elif "A110" not in filename and "A837" not in filename and "A348" not in filename:
                    os.remove(os.path.join(dir2023, filename))
            print('Finished downloading 2023')
        except Exception as e:
            print("Error while updating 2023: ", e)
    
    # Download Year
    def download2023Windows(self):
        try:
            # Download, test with filipe
            print('Downloading 2023')
            URL = "https://portal.inmet.gov.br/uploads/dadoshistoricos/2023.zip"
            dir2023 = os.path.join(self.DIR, "2023")

            if not os.path.exists(dir2023):
                os.mkdir(dir2023)
            else:
                for filename in os.listdir(dir2023):
                    os.remove(os.path.join(dir2023, filename))

            # Download zip file to Dados folder
            r = requests.get(URL, allow_redirects=True)
            open(os.path.join(dir2023, '2023.zip'), 'wb').write(r.content)

            # Unzip file
            with ZipFile(os.path.join(dir2023, '2023.zip'), 'r') as zip_ref:
                zip_ref.extractall(dir2023)

            # Now we delete everything except the CSV files that have "A110", "A837" and "A348" in their name
            for filename in os.listdir(dir2023):
                if not filename.endswith(".CSV"):
                    os.remove(os.path.join(dir2023, filename))
                elif "A110" not in filename and "A837" not in filename and "A348" not in filename:
                    os.remove(os.path.join(dir2023, filename))

            print('Finished downloading 2023')

        except Exception as e:
            print("Error while updating 2023: ", e)

    def run(self, yearArray = None):
        if yearArray is None:
            yearArray = self.YEARS

        for year in yearArray:
            FOLDER_YEAR = os.path.join(self.DIR, year)
            if not os.path.exists(FOLDER_YEAR):
                print("Folder does not exist: ", FOLDER_YEAR)
                continue
            for filename in os.listdir(FOLDER_YEAR):
                # Check if filename has A110, A837 or A348, otherwise delete it
                if not filename.endswith(".CSV"):
                    os.remove(os.path.join(FOLDER_YEAR, filename))
                    continue
                elif "A110" not in filename and "A837" not in filename and "A348" not in filename:
                    os.remove(os.path.join(FOLDER_YEAR, filename))
                    continue 
                # Header
                header = self.get_header_from_csv(filename, FOLDER_YEAR)
                if header is None:
                    continue
                # Body
                body = self.get_data_from_csv(filename, FOLDER_YEAR)
                # Insert new station, then insert data for that station
                self.insert_header(header)
                for row in body:
                    self.insert_data(row, header['codigo'])

    # General Functions
    def update2023(self):
        self.download2023Windows()
        self.run(["2023"])
    
#db = database()
#test = generateInserts(db)
#test.run()
#test.update2023()
