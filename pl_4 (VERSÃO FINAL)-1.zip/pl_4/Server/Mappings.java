// If when exectuing, mappping breaks or cannot be found, just put everything on server and edit the statuc var
// Then it should be fine, there is a example there of how each function should look like at the end of the file
public class Mappings {
    // Mappings
    public String temperatura_orvalho(float value) {
        System.out.println("temperatura_orvalho" + value);
        return "low";
    }

    public String temperatura_maxima(float value) {
        // Std dev = 6 and avg = 25, return low, avg or high
        System.out.println("temperatura_maxima: " + value);
        if (value < 19) {
            return "low";
        } else if (value < 31) {
            return "avg";
        } else {
            return "high";
        }
    }

    public String temperatura_minima(float value) {
        // 21 6
        System.out.println("temperatura_minima: " + value);
        if (value < 15) {
            return "low";
        } else if (value < 27) {
            return "avg";
        } else {
            return "high";
        }
    }
    
    public String precipitacao_total(float value) {
        // 1.25 0.1
        System.out.println("precipitacao_total: " + value);
        if (value < 1.15) {
            return "low";
        } else if (value < 1.35) {
            return "avg";
        } else {
            return "high";
        }
    }
    
    public String pressao_atmosferica(float value) {
        System.out.println("pressao_atmosferica: " + value);
        return "low";
    }
    
    public String pressao_atmosferica_maxima(float value) {
        System.out.println("pressao_atmosferica_maxima: " + value);
        return "low";
    }
    
    public String pressao_atmosferica_minima(float value) {
        System.out.println("pressao_atmosferica_minima: " + value);
        return "low";
    }
    
    public String radiacao_global(float value) {
        System.out.println("radiacao_global: " + value);
        return "low";
    }
    
    public String temperatura(float value) {
        System.out.println("temperatura: " + value);
        return "low";
    }

    public String temperatura_orvalho_maxima(float value) {
        System.out.println("temperatura_orvalho_maxima: " + value);
        return "low";
    }
    
    public String temperatura_orvalho_minima(float value) {
        System.out.println("temperatura_orvalho_minima: " + value);
        return "low";
    }
    
    public String umidade_maxima(float value) {
        System.out.println("umidade_maxima: " + value);
        return "low";
    }
    
    public String umidade_minima(float value) {
        System.out.println("umidade_minima: " + value);
        return "low";
    }
    
    public String umidade_relativa(float value) {
        System.out.println("umidade_relativa: " + value);
        return "low";
    }
    
    public String vento_direcao(float value) {
        System.out.println("vento_direcao: " + value);
        return "low";
    }
    
    public String vento_rajada_maxima(float value) {
        System.out.println("vento_rajada_maxima: " + value);
        return "low";
    }
    
    public String vento_velocidade(float value) {
        System.out.println("vento_velocidade: " + value);
        return "low";
    }
    
}
