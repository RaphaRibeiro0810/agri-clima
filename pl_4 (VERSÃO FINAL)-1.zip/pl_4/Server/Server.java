import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiFunction;

public class Server {

    public static final String ERR_RETURN_MSG = "server_error";
    public static int PORT_NUMBER = 12345;
    private static final Map<String, BiFunction<Float, Float, String>> parameterActions = new HashMap<>();
    public static Mappings Mappings = new Mappings();
    
    static {
        parameterActions.put("temperatura_orvalho", (param, val) -> Mappings.temperatura_orvalho(val));
        parameterActions.put("precipitacao_total", (param, val) -> Mappings.precipitacao_total(val));
        parameterActions.put("pressao_atmosferica", (param, val) -> Mappings.pressao_atmosferica(val));
        parameterActions.put("pressao_atmosferica_maxima", (param, val) -> Mappings.pressao_atmosferica_maxima(val));
        parameterActions.put("pressao_atmosferica_minima", (param, val) -> Mappings.pressao_atmosferica_minima(val));
        parameterActions.put("radiacao_global", (param, val) -> Mappings.radiacao_global(val));
        parameterActions.put("temperatura", (param, val) -> Mappings.temperatura(val));
        parameterActions.put("temperatura_maxima", (param, val) -> Mappings.temperatura_maxima(val));
        parameterActions.put("temperatura_minima", (param, val) -> Mappings.temperatura_minima(val));
        parameterActions.put("temperatura_orvalho_maxima", (param, val) -> Mappings.temperatura_orvalho_maxima(val));
        parameterActions.put("temperatura_orvalho_minima", (param, val) -> Mappings.temperatura_orvalho_minima(val));
        parameterActions.put("umidade_maxima", (param, val) -> Mappings.umidade_maxima(val));
        parameterActions.put("umidade_minima", (param, val) -> Mappings.umidade_minima(val));
        parameterActions.put("umidade_relativa", (param, val) -> Mappings.umidade_relativa(val));
        parameterActions.put("vento_direcao", (param, val) -> Mappings.vento_direcao(val));
        parameterActions.put("vento_rajada_maxima", (param, val) -> Mappings.vento_rajada_maxima(val));
        parameterActions.put("vento_velocidade", (param, val) -> Mappings.vento_velocidade(val));
    }

    public static void main(String[] args) {
        if (args.length > 0) {
            if (isInteger(args[0])) {
                try {
                    PORT_NUMBER = Integer.parseInt(args[0]);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid port number: " + args[0]);
                    System.exit(-1);
                }
            } else {
                System.out.println("Invalid port number: " + args[0]);
                System.exit(-1);
            }
        }

        try (ServerSocket serverSocket = new ServerSocket(PORT_NUMBER)) {
            System.out.println("Java Socket Server is listening on port " + PORT_NUMBER);

            while (true) {
                try {
                    Socket clientSocket = serverSocket.accept();

                    // Create a new thread for each client
                    Thread clientHandlerThread = new Thread(() -> handleClient(clientSocket));
                    clientHandlerThread.start();

                } catch (IOException e) {
                    System.err.println("Error handling client connection: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("Could not listen on port " + PORT_NUMBER);
            System.exit(-1);
        }
    }

    private static void handleClient(Socket clientSocket) {
        try (
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
        ) {
            // Get message from Python client
            String message = in.readLine();

            // First check if message will be valid for parsing later
            boolean isValid = isValidMessage(message);
            if (!isValid) {
                System.out.println("Received invalid message from Python client: " + message);
                out.println("server_error");
                return;
            } else {
                System.out.println("Received message from Python client: " + message);
            }

            // Run main function and send response
            String res = getResponse(message);
            System.out.println("Sent response to Python client " + res);
            out.println(res);

        } catch (IOException e) {
            System.err.println("Error handling client connection: " + e.getMessage());
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // Main function
    private static String getResponse(String message) 
    {
        // Make parameters
        String[] messageArray = message.split(",");
        String parameter = messageArray[0];
        float value = Float.parseFloat(messageArray[1]);

        // Check if parameter has a defined action
        BiFunction<Float, Float, String> action = parameterActions.get(parameter);
        if (action != null) {
            return action.apply(value, value);
        } else {
            // Return error if parameter is unknown
            System.out.println("Unknown parameter: " + parameter);
            return "server_error";
        }
    }

    // Checker functions
    private static boolean isValidMessage(String message) 
    {
        // Check if the message is null
        if (message == null) {
            return false;
        }
        try {
            // Splitting the message
            String[] messageArray = message.split(",");
            
            // Checking if the array has exactly two parts
            if (messageArray.length != 2) {
                return false;
            }

            // Attempting to parse the second part as a float
            float value = Float.parseFloat(messageArray[1]);

            // If no exception is thrown, the message is considered valid
            return true;
        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            // Catching exceptions that may occur during parsing or array access
            return false;
        }
    }

    public static boolean isNumeric(String str) 
    { 
        try {  
            Float.parseFloat(str);  
            return true;
        } catch(NumberFormatException e){  
            return false;  
        }  
    }

    public static boolean isInteger(String str) 
    { 
        try {  
            Integer.parseInt(str);  
            return true;
        } catch(NumberFormatException e){  
            return false;  
        }  
    }

    /*
        Examples:
        // Mapping but function is here
        private static String temperatura_maxima(float value) {
            System.out.println("temperatura_maxima: " + value);
            return "noerror";
        }
        // For synchronized methods
        private static synchronized void updateState(int newState) {
            STATE = newState;
        }
    */
    
}