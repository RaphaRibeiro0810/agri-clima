import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardBody, GridItem, Flex, Center, Heading, Text} from '@chakra-ui/react'
/*
    data vem com as keys:
        precipitacao_total_avg
        precipitacao_total_max
        precipitacao_total_min
        temperatura_avg
        temperatura_max
        temperatura_maxima_avg
        temperatura_maxima_max
        temperatura_maxima_min
        temperatura_min
        temperatura_minima_avg
        temperatura_minima_max
        temperatura_minima_min
*/
const MyCard = ({title = 'dataset',index='', data, colorIndex}) => {

    const [colorIndexFinal, setColorIndexFinal] = useState('white');

    const fetchData = async () => {
        console.log("fetching data");
        console.log(typeof data[index]);
        if (index == '' || data == undefined) {
            // If colorIndex is undefined or data[index] is not a number, return early
            return;
        }
        try {
            let url = "http://127.0.0.1:5000/serverRequest/" + colorIndex + "/" + data[index];
            console.log(url);
            console.log(data[index] + " " + colorIndex)
            const response = await fetch(url).then((response) => response.json());
            let res = response['response'];
            if (res == 'low'){
                setColorIndexFinal('#D6BCFA');
            } else if (res == 'avg'){
                setColorIndexFinal('#9AE6B4');
            } else if (res == 'high'){
                setColorIndexFinal('#E53E3E');
            } else {
                setColorIndexFinal('white');
            }

        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    //Call fetchData every time the index changes
    useEffect(() => {
        fetchData();
    }, [data]);
     


    return (
        <GridItem w="100%" h="200" colSpan={{ base: 6, lg: 2 }}>
            <Flex direction="column" alignItems="center" justifyContent="center" w="100%" h="100%" p={2}>
                <Card align='center' w="100%" h="100%" bg={colorIndexFinal} boxShadow="dark-lg" rounded="md" borderColor="gray.200" overflow="hidden">
                    {data ? (
                        <>
                            <CardHeader>
                                <Heading size='md'>{title}</Heading>
                            </CardHeader>
                            <CardBody>
                                <Center><Text fontSize='3xl'>{data[index]}</Text></Center>
                            </CardBody>
                        </>
                    ) : (
                        <Center>Loading...</Center>
                    )}
                </Card>
            </Flex>
        </GridItem>
    );
}


export default MyCard;
