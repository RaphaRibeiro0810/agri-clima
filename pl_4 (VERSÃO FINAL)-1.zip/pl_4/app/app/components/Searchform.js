import React, { useEffect } from "react";
import { Select, HStack } from "@chakra-ui/react";

const SearchForm = ({ string, setDayStart, setMonthStart, setYearStart }) => {
  const days = [...Array(31).keys()].map(i => i + 1);
  const months = [...Array(12).keys()].map(i => i + 1);
  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 100 }, (_, i) => currentYear - i);

  return (
    <HStack spacing='24px'>
      <h2>{string}</h2>
      <Select placeholder="Day" size='md' textAlign='center' onChange={(e) => setDayStart(e.target.value)}>
        {days.map((day, index) => (
          <option key={index} value={day}>
            {day}
          </option>
        ))}
      </Select>
      <Select placeholder="Month" size='md' textAlign='center' onChange={(e) => setMonthStart(e.target.value)}>
        {months.map((month, index) => (
          <option key={index} value={month}>
            {month}
          </option>
        ))}
      </Select>
      <Select placeholder="Year" size='md' textAlign='center' onChange={(e) => setYearStart(e.target.value)}>
        {years.map((year, index) => (
          <option key={index} value={year}>
            {year}
          </option>
        ))}
      </Select>
    </HStack>
  );
};

export default SearchForm;