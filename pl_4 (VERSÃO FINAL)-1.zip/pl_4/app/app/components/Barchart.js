import React, { useState, useEffect } from 'react';
import { GridItem, Flex, Center } from '@chakra-ui/react'
import { Bar } from 'react-chartjs-2';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';
ChartJS.register( CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend );
const labels = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
const data = {
    labels,
    datasets: [
        {
            label: 'Dataname',
            data: [1,2,3,4],
            backgroundColor: 'rgba(49,130,206,255)',
        },
    ],
};
const Barchart = ({title = 'Dataset', dataNew = data}) => {
    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: title,
            },
        },
    };
    return (
        <GridItem w='100%' colSpan={{ base: 6, lg: 3 }}>
          <Flex direction="column" alignItems="center" justifyContent="center" h="100%" p={2}>
            {dataNew.labels && dataNew.datasets ? (
              <Bar options={options} data={dataNew} />
            ) : (
              <Center>Loading...</Center>
            )}
          </Flex>
        </GridItem>
    );       
};

export default Barchart;
