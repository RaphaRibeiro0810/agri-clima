import React, { useState, useEffect } from 'react';
import { Chart as ChartJS, LinearScale, CategoryScale, BarElement, PointElement, LineElement, Legend, Tooltip, LineController, BarController, } from 'chart.js';
import { Chart } from 'react-chartjs-2';
import { GridItem, Flex, Center } from '@chakra-ui/react'
ChartJS.register( LinearScale, CategoryScale, BarElement, PointElement, LineElement, Legend, Tooltip, LineController, BarController );
const labels = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
export const data = {
    labels,
    datasets: [
      {
        type: 'line',
        label: 'Dataset 1',
        borderColor: 'rgb(255, 99, 132)',
        borderWidth: 2,
        fill: false,
        data: [1,2,3,4,5,6,7]
      },
      {
        type: 'bar',
        label: 'Dataset 2',
        backgroundColor: 'rgb(75, 192, 192)',
        data: [1,2,3,4,5,6,7],
        borderColor: 'white',
        borderWidth: 2,
      },
    ]
}
const MultitypechartFixed = ({title = 'Dataset', dataNew = data}) => {
  return ( 
    <GridItem w='100%' colSpan={{ base: 6, lg: 3 }}>
        <Flex direction="column" alignItems="center" justifyContent="center" w="100%" p={2}>
            { (dataNew['labels'] && dataNew['datasets']) ?
            (
                <Chart type='bar' data={dataNew} />
            ) : (
                <Center>Loading... MultitypechartFixed</Center>
            )}
        </Flex>
    </GridItem>
  );
};

export default MultitypechartFixed;
