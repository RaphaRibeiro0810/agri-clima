
import React from 'react';
import { Select } from "@chakra-ui/react";

const Stations = ({stations, setSelectedStation}) => {
  return (
    <Select placeholder="Select Station" size='md' textAlign='center' onChange={(e) => setSelectedStation(e.target.value)}>
    {stations.map((station, index) => (
      <option key={index} value={station[0]}>
        {station[1]} ({station[0]})
      </option>
    ))}
  </Select>
  );
};

export default Stations;
