'use client'
import React, { useState, useEffect } from 'react';
import { Grid, GridItem, Flex, ChakraProvider, Button, Text } from '@chakra-ui/react';
import SearchForm from './components/Searchform';
import Stations from './components/Stations';
import Barchart from './components/Barchart';
import Linechart from './components/Linechart';
import MyCard from './components/Card';
import MultitypechartFixed from './components/Multitypechart_fixed';

export default function Home() {
  useEffect(() => {
    getDropdownStations();
  }, []);

  // PARTIAL DATES
  const [dayStart, setDayStart] = useState(null);
  const [monthStart, setMonthStart] = useState(null);
  const [yearStart, setYearStart] = useState(null);
  const [dayEnd, setDayEnd] = useState(null);
  const [monthEnd, setMonthEnd] = useState(null);
  const [yearEnd, setYearEnd] = useState(null);

  // FULL DATES
  const [dateStart, setDateStart] = useState(null);
  const [dateEnd, setDateEnd] = useState(null);
  useEffect(() => {
    let dateStringStart = `${yearStart}-${monthStart}-${dayStart}`;
    let dateStringEnd = `${yearEnd}-${monthEnd}-${dayEnd}`;
    setDateStart(dateStringStart);
    setDateEnd(dateStringEnd);
    console.log('Start Date: ' + dateStringStart + ' End Date: ' + dateStringEnd);
  }, [dayStart, monthStart, yearStart, dayEnd, monthEnd, yearEnd]);

  // STATIONS
  const [stations, setStations] = useState([]);
  const [selectedStation, setSelectedStation] = useState(null);
  const getDropdownStations = async () => {
    let url = "http://127.0.0.1:5000/getStations";
    const response = await fetch(url).then((response) => response.json());
    let stations = response['stations'];
    // add all option
    stations.unshift(['all', 'All']);
    setStations(stations);
  }

  // LABELS 
  const [monthLabels, setMonthLabels] = useState([]);
  const [dayLabels, setDayLabels] = useState([]);
  const [dayHourLabels, setdayHourLabels] = useState([]);

  // DATASETS
  const [dataset_Monthly, setDataset_Monthly] = useState([]);
  const [radiationDataset_Weekly, setRadiationDataset_Weekly] = useState([]);
  const [dataset_Daily, setDataset_Daily] = useState([]);
  const [dataset_Fixed, setDataset_Fixed] = useState([]);
  const [dataset_Extra, setDataset_Extra] = useState([]);
  const [mixData, setMixData] = useState([]);

  //IS LOADING STATE
  const [isLoading, setIsLoading] = useState(false);

  //Run all routes
  const setLabels = async () => {
    if (!checkDates()) { return; }
    try {
      await dayLabelsStateRequest();
      await monthLabelsStateRequest();
      await dayHourLabelsStateRequest();
      //Data Calculations
      await calculateDataset_Monthly();
      await calculateRadiationDataset_Weekly();
      await calculateDataset_Daily();
      await calculateMixData();
      await calculateDataset_fixed();
      await calculateDataset_Extra();
    } catch (error) {
      // Handle errors here
      console.error('An error occurred:', error);
    }
  };

  //Update dataset on click
  const runDataset = async () => {
    //ask if user wants to proceed
    let result = window.confirm('Are you sure you want to reload/load the dataset ?');
    if (!result) { return; }
    let url = "http://127.0.0.1:5000/run"
    setIsLoading(true);
    const response = await fetch(url).then((response) => response.json()).then((response) => {
      setIsLoading(false);
      return response;
    });
    //Check if result hgas message: run
    if (response['message'] === 'run') {
      alert('Run complete');
    } else {
      alert('Run failed');
    }
  }
  const run2023 = async () => {
    //ask if user wants to proceed
    let result = window.confirm('Are you sure you want to reload/load the 2023 dataset ?');
    if (!result) { return; }
    let url = "http://127.0.0.1:5000/update-2023"
    setIsLoading(true);
    const response = await fetch(url).then((response) => response.json()).then((response) => {
      setIsLoading(false);
      return response;
    });
    //Check if result hgas message: run
    if (response['message'] === 'update-2023') {
      alert('Run complete');
    } else {
      alert('Run failed');
    }
  }

  //Labels
  const monthLabelsStateRequest = async () => {
    let url = "http://127.0.0.1:5000/getMonthLabel/" + dateStart + "/" + dateEnd;
    const response = await fetch(url).then((response) => response.json());
    let monthLabels = response['months'];
    monthLabels = monthLabels.map((month) => {
      return month[0];
    });
    setMonthLabels(monthLabels);
  };
  const dayLabelsStateRequest = async () => {
    let url = "http://127.0.0.1:5000/getDayLabel/" + dateStart + "/" + dateEnd;
    const response = await fetch(url).then((response) => response.json());
    let days = response['days'];
    days = days.map((day) => {
      return day[0];
    });
    setDayLabels(days);
  };
  const dayHourLabelsStateRequest = async () => {
    let url = "http://127.0.0.1:5000/getHourLabel/" + dateStart + "/" + dateEnd;
    const response = await fetch(url).then((response) => response.json());
    let dayHours = response['hours'];
    dayHours = dayHours.map((dayHour) => {
      return dayHour[0];
    });
    setdayHourLabels(dayHours);
  };

  //Monthly Datasets
  const calculateDataset_Monthly = async () => {
    if (dateStart === null || dateEnd === null || selectedStation === null) { return; }
    let url = "http://127.0.0.1:5000/getMonthData/" + dateStart + "/" + dateEnd + "/" + selectedStation;
    const response = await fetch(url).then((response) => response.json());
    let rad = response['res'];
    let dataset = await generateDataset('Vel. vento', rad);
    setDataset_Monthly(dataset);
  }
  //Weekly Datasets
  const calculateRadiationDataset_Weekly = async () => {
    if (dateStart === null || dateEnd === null || selectedStation === null) { return; }
    let url = "http://127.0.0.1:5000/getRadiationWeek/" + dateStart + "/" + dateEnd + "/" + selectedStation;
    const response = await fetch(url).then((response) => response.json());
    let rad = response['radiation'];
    let dataset = await generateDataset('Radiation By Week', rad);
    setRadiationDataset_Weekly(dataset);
  }
  //Daily Datasets
  const calculateDataset_Daily = async () => {
    if (dateStart === null || dateEnd === null || selectedStation === null) { return; }
    let url = "http://127.0.0.1:5000/getDailyUpdate/" + dateStart + "/" + dateEnd + "/" + selectedStation;
    const response = await fetch(url).then((response) => response.json());
    let data = response['res'];
    let dataset = await generateDataset('Umidade Relativa', data);
    setDataset_Daily(dataset);
  }
  //Exta Graph
  const calculateDataset_Extra = async () => {
    if (dateStart === null || dateEnd === null || selectedStation === null) { return; }
    let url = "http://127.0.0.1:5000/getClimogramaDataset/" + dateStart + "/" + dateEnd + "/" + selectedStation;
    const response = await fetch(url).then((response) => response.json());
    let data = response['dataset'];
    setDataset_Extra(data);
  }
  //Fixed dataset
  const calculateDataset_fixed = async () => {
    let url = "http://127.0.0.1:5000/getFixedDataset";
    const response = await fetch(url).then((response) => response.json());
    let data = response['dataset'];
    setDataset_Fixed(data);
  }
  //Card Datasets
  const calculateMixData = async () => {
    if (dateStart === null || dateEnd === null || selectedStation === null) { return; }
    let url = "http://127.0.0.1:5000/getMixData/" + dateStart + "/" + dateEnd + "/" + selectedStation;
    const response = await fetch(url).then((response) => response.json());
    let res = response['mixData'];
    setMixData(res[0]);
  }
  // Checkers
  function checkDates() {
    if (dayStart === null || monthStart === null || yearStart === null) { alert('Please select a proper start date'); return false; }
    if (dayEnd === null || monthEnd === null || yearEnd === null) { alert('Please select a proper end date'); return false; }
    if (selectedStation === null) { alert('Please select a station'); return false; }
    //Check if dateStart is before dateEnd
    let dateStart = new Date(yearStart, monthStart, dayStart);
    let dateEnd = new Date(yearEnd, monthEnd, dayEnd);
    if (dateStart > dateEnd) { alert('Date start is bigger than date end, fix the dates'); return false; }
    return true;
  }
  function checkLabels() {
    if (
      monthLabels && monthLabels.length > 0 &&
      dayLabels && dayLabels.length > 0 &&
      dayHourLabels && dayHourLabels.length > 0 
    ) {
      return true;
    }
    return false;
  }
  // Dataset Generator (For simple [label,data] datasets])
  const generateDataset = async (title, inputData, color = 'rgba(49,130,206,255)') => {
    let labels = [];
    let dataValues = [];

    for (let i = 0; i < inputData.length; i++) {
      labels.push(inputData[i][0]);
      dataValues.push(inputData[i][1]);
    }

    //Check if length is equal to each other, and check if length is greater than 0
    if (labels.length !== dataValues.length || labels.length === 0 || dataValues.length === 0) {
      return null;
    }
  
    let result = {
      labels,
      datasets: [
        {
          label: title,
          data: dataValues,
          backgroundColor: color,
        }
      ],
    };
  
    return result;
  }
  return (
    <ChakraProvider>
      {
        !isLoading ? (
          <Grid templateColumns='repeat(6, 1fr)' gap={6} p={2}>
            <GridItem w='100%' colSpan={{ base: 6, lg: 2 }}>
              <Flex direction="column" alignItems="center" justifyContent="center" h="100%" p={2}>
                <SearchForm
                  string='Start'
                  setDayStart={setDayStart}
                  setMonthStart={setMonthStart}
                  setYearStart={setYearStart}
                />
              </Flex>
            </GridItem>
            <GridItem w='100%' colSpan={{ base: 6, lg: 2 }}>
              <Flex direction="column" alignItems="center" justifyContent="center" h="100%" p={2}>
                <SearchForm
                  string='End'
                  setDayStart={setDayEnd}
                  setMonthStart={setMonthEnd}
                  setYearStart={setYearEnd}
                />
              </Flex>
            </GridItem>
            <GridItem w='100%' colSpan={{ base: 6, lg: 1 }}>
              <Flex direction="column" alignItems="center" justifyContent="center" h="100%" p={2}>
                <Stations stations={stations} setSelectedStation={setSelectedStation} />
              </Flex>
            </GridItem>
            <GridItem w='100%' colSpan={{ base: 6, lg: 1 }}>
              <Flex direction="row" alignItems="center" justifyContent="center" h="100%" p={1}>
                <Button colorScheme="green" size="md" w={'15%'} onClick={run2023} m={1}>
                  2023
                </Button>
                <Button colorScheme="red" size="md" w={'15%'} onClick={runDataset} m={1}>
                  All
                </Button>
                <Button colorScheme="blue" size="md" w={'70%'} onClick={setLabels} m={1}>
                  Search Dates
                </Button>
              </Flex>
            </GridItem>
            { 
              (checkLabels() && dataset_Monthly) &&
              <Barchart title='Velocidade Vento' dataNew={dataset_Monthly} /> 
            }
            {
              (checkLabels() && radiationDataset_Weekly) &&
              <Linechart title='Radiacao por semana' dataNew={radiationDataset_Weekly} />
            }
            {
              (checkLabels() && mixData) &&
              <>
                <MyCard title='Precipitacao Total Media' index='precipitacao_total_avg' data={mixData} colorIndex='precipitacao_total'/>
                <MyCard title='Temperatura Maxima Media' index='temperatura_maxima_avg' data={mixData} colorIndex='temperatura_maxima'/>
                <MyCard title='Temperatura Minima Media' index='temperatura_minima_avg' data={mixData} colorIndex='temperatura_minima'/>
              </>
            }
            {
              (checkLabels() && dataset_Extra) &&
              <MultitypechartFixed title='Climograma' dataNew={dataset_Extra}  />
            }
            {
              (checkLabels() && dataset_Fixed) &&
              <MultitypechartFixed title='Fixed' dataNew={dataset_Fixed}  />
            }
            {
              (checkLabels() && dataset_Daily) &&
              <Linechart title='Umidade Relativa' dataNew={dataset_Daily} />
            }
          </Grid>
        ) : (
          <Text>Loading...</Text>
        )
      }
    </ChakraProvider>
  )
}