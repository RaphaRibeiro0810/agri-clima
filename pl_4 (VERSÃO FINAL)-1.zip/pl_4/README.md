# Rodar Localmente

## Requisitos

1. Clone o projeto para o seu ambiente local.
2. Navegue até o repositório do projeto.
3. Instale todas as dependências do Python. Você pode encontrá-las no arquivo `Python/requirements.txt`. (`pip install -r requirements.txt`)
4. Crie um banco de dados no MySQL Workbench e um esquema (schema) com o nome, por exemplo, "projetointegrador4".
5. Certifique-se de que a conexão com o MySQL esteja ativa. Você pode configurar a conexão dentro do arquivo `Python/databaseSetup.py`, fornecendo suas informações de usuário, senha, host, etc.

## Execução

6. Execute o arquivo `main.py` para iniciar a API em Flask.
7. Se necessário, você pode executar manualmente o arquivo `generateInserts.py` para verificar erros.
